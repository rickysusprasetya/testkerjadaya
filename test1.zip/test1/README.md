# wheame

A Flutter project. Integrate with API AirVisual

<img src="https://raw.githubusercontent.com/hifiaz/weather/master/flutter_01.png" width="240"/>
<img src="https://raw.githubusercontent.com/hifiaz/weather/master/flutter_02.png" width="240"/>

## Getting Started

To use this plugin, add `hooks_riverpod` `http` `intl` as a [dependency in your pubspec.yaml](https://flutter.io/platform-plugins/).

befor it you must create API Key in [iqair.com](https://www.iqair.com/id/air-pollution-data-api)